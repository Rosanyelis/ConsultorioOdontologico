<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="js">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Consultorio Dental')); ?></title>

        <meta content="Gestión de Consultorio Odontológico" name="description" />
        <meta content="Ross Digital" name="author" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="<?php echo e(asset('./images/favicon.png')); ?>">
        <!-- StyleSheets  -->
        <link rel="stylesheet" href="<?php echo e(asset('./assets/css/dashlite.css?ver=2.9.0')); ?>">
        <link id="skin-default" rel="stylesheet" href="<?php echo e(asset('./assets/css/theme.css?ver=2.9.0')); ?>">
        <?php echo $__env->yieldContent('styles'); ?>
    </head>
    <body class="nk-body ui-rounder npc-default has-sidebar ">
        <div class="nk-app-root">
            <div class="nk-sidebar" data-content="sidebarMenu">
                <?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

            <!-- main @s -->
            <div class="nk-main ">
                <!-- wrap @s -->
                <div class="nk-wrap ">
                    <!-- main header @s -->
                    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <!-- main header @e -->
                    <!-- content @s -->
                    <div class="nk-content ">
                        <div class="container-fluid">

                            <?php echo $__env->yieldContent('content'); ?>
                            <!--<div class="nk-content-inner">
                                <div class="nk-content-body">
                                    <p>Starter page for Demo7 layout.</p>
                                </div>
                            </div>-->
                        </div>
                    </div>
                    <!-- content @e -->
                </div>
                <!-- wrap @e -->
            </div>

        <!-- main @e -->
        </div>
        <!-- app-root @e -->
        <!-- JavaScript -->
        <script src="<?php echo e(asset('./assets/js/bundle.js?ver=2.9.0')); ?>"></script>
        <script src="<?php echo e(asset('./assets/js/scripts.js?ver=2.9.0')); ?>"></script>
        <script>
            (function(NioApp, $){
                'use strict';

                <?php echo $__env->make('layouts.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                function mostrarFechaHoraActual() {
                    // Obtener la fecha y hora actual
                    const fechaActual = new Date();

                    // Obtener las horas, minutos y segundos
                    const horas = fechaActual.getHours();
                    const minutos = fechaActual.getMinutes();
                    const segundos = fechaActual.getSeconds();

                    // Obtener el meridiano (AM/PM)
                    const meridiano = horas >= 12 ? "PM" : "AM";

                    // Formatear la hora con dos dígitos
                    const horaFormateada = `${horas.toString().padStart(2, "0")}:${minutos.toString().padStart(2, "0")}:${segundos.toString().padStart(2, "0")} ${meridiano}`;

                    // Formatear la fecha
                    const fechaFormateada = `${fechaActual.getDate().toString().padStart(2, "0")} / ${(fechaActual.getMonth() + 1).toString().padStart(2, "0")} / ${fechaActual.getFullYear()}`;

                    // Actualizar el contenido de un elemento HTML con la fecha y hora formateada
                    document.getElementById("DateToday").textContent = `${fechaFormateada} - ${horaFormateada}`;

                    // Repetir la función cada segundo para actualizar la fecha y hora en tiempo real
                    setTimeout(mostrarFechaHoraActual, 1000);
                }

                    // Iniciar la función para mostrar la fecha y hora actual
                    mostrarFechaHoraActual();

            })(NioApp, jQuery);
        </script>
        <?php echo $__env->yieldContent('scripts'); ?>
    </body>

</html>

<?php /**PATH C:\laragon\www\ConsultorioOdontologico\resources\views/layouts/app.blade.php ENDPATH**/ ?>