                                                            <div class="nk-block nk-block-between">
                                                                <div class="nk-block-head">
                                                                    <h6 class="title">Recetas</h6>
                                                                </div><!-- .nk-block-head -->
                                                                <div class="nk-block">
                                                                    <a href="<?php echo e(route('patient.recipe', $data->id)); ?>" class="btn btn-icon btn-primary">
                                                                        <em class="icon ni ni-plus"></em>
                                                                    </a>
                                                                </div>
                                                            </div><!-- .nk-block-between  -->
                                                            <div class="nk-block">
                                                                <table class="datatable-init table">
                                                                    <thead>
                                                                        <tr>
                                                                            <th width="50px">#</th>
                                                                            <th>Observación</th>
                                                                            <th>Fecha de Receta</th>
                                                                            <th class="text-right">Acciones</th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                        <?php $__currentLoopData = $data->recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <tr>
                                                                            <td><?php echo e($item->id); ?></td>
                                                                            <td><?php echo e($item->observations); ?></td>
                                                                            <td><?php echo e(\Carbon\Carbon::createFromDate($item->created_at)->format('d-m-Y')); ?></td>
                                                                            <td></td>
                                                                        </tr>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </tbody>
                                                                </table>
                                                            </div><!-- .nk-block -->
<?php /**PATH C:\laragon\www\ConsultorioOdontologico\resources\views/patients/partials/recipes.blade.php ENDPATH**/ ?>