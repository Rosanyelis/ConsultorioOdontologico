                        <div class="modal fade" tabindex="-1" id="modalSignature">
                            <div class="modal-dialog" role="document">
                                <form action="<?php echo e(route('patient.import')); ?>" method="POST" class="modal-content"
                                    autocomplete="off" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                                        <em class="icon ni ni-cross"></em>
                                    </a>
                                    <div class="modal-header">
                                        <h5 class="modal-title">Agregar Firma de Paciente</h5>
                                    </div>
                                    <div class="modal-body">
                                        <div class="row g-4">
                                            <div class="col-xxl-12 col-md-12">
                                                <div id="signature-pad" class="signature-pad">
                                                    <div class="signature-pad--body">
                                                        <canvas></canvas>
                                                    </div>
                                                    <div class="signature-pad--footer">

                                                        <div class="signature-pad--actions">
                                                            <div>
                                                                <!-- <button type="button" class="button clear" data-action="clear">Borrar</button> -->

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer bg-light">
                                        <button type="button" id="clearBtn" class="btn btn-danger">Borrar Firma</button>
                                        <button type="submit" class="btn btn-secondary">Crear Imagen Firma</button>
                                        <button type="submit" class="btn btn-primary float-right">Guardar Firma</button>
                                    </div>
                                </form>
                            </div>
                        </div>
<?php /**PATH C:\laragon\www\ConsultorioOdontologico\resources\views/patients/partials/modal-signature.blade.php ENDPATH**/ ?>