                                                            <div class="nk-block nk-block-between">
                                                                <div class="nk-block-head">
                                                                    <h6 class="title">Pagos</h6>
                                                                </div><!-- .nk-block-head -->
                                                                <div class="nk-block">
                                                                    <a href="<?php echo e(route('patient.pay', $data->id)); ?>"
                                                                        class="btn btn-icon btn-primary">
                                                                        <em class="icon ni ni-plus"></em>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                            <div class="nk-block">
                                                                <table class="datatable-init table">
                                                                    <thead>
                                                                        <tr>
                                                                            <th width="50px">#</th>
                                                                            <th>Factura #</th>
                                                                            <th>Tipo de Pago</th>
                                                                            <th>Nro. Cuotas</th>
                                                                            <th>Total</th>
                                                                            <th>Estatus</th>
                                                                            <th class="text-right">Acciones</th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                        <?php $__currentLoopData = $data->billings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <tr>
                                                                            <td><?php echo e($loop->iteration); ?></td>
                                                                            <td>#000<?php echo e($item->id); ?></td>
                                                                            <td><?php echo e($item->payment_type); ?></td>
                                                                            <td><?php echo e($item->number_installments); ?></td>
                                                                            <td><?php echo e($item->total); ?></td>
                                                                            <td>
                                                                                <?php if($item->status == 'Pagado'): ?>
                                                                                <span class="badge badge-success"><?php echo e($item->status); ?></span>
                                                                                <?php endif; ?>
                                                                                <?php if($item->status == 'Pendiente'): ?>
                                                                                <span class="badge badge-warning"><?php echo e($item->status); ?></span>
                                                                                <?php endif; ?>
                                                                                <?php if($item->status == 'Cancelado'): ?>
                                                                                <span class="badge badge-danger"><?php echo e($item->status); ?></span>
                                                                                <?php endif; ?>
                                                                            </td>
                                                                            <td class="text-right">
                                                                                <div class="dropdown float-right">
                                                                                    <a href="#" class="dropdown-toggle btn btn-icon btn-trigger pt-0 pb-0" data-toggle="dropdown">
                                                                                        <em class="icon ni ni-more-h"></em>
                                                                                    </a>
                                                                                    <div class="dropdown-menu dropdown-menu-right">
                                                                                        <ul class="link-list-opt no-bdr">
                                                                                            <li>
                                                                                                <a href="#">
                                                                                                    <em class="icon ni ni-eye"></em>
                                                                                                    <span>Ver Factura</span>
                                                                                                </a>
                                                                                            </li>
                                                                                            <li>
                                                                                                <a href="#">
                                                                                                    <em class="icon ni ni-pen-fill"></em>
                                                                                                    <span>Editar Factura</span>
                                                                                                </a>
                                                                                            </li>
                                                                                            <?php if($item->status == 'Pendiente'): ?>
                                                                                            <li>
                                                                                                <a href="#">
                                                                                                    <em class="icon ni ni-file-plus"></em>
                                                                                                    <span>Abonar Factura</span>
                                                                                                </a>
                                                                                            </li>
                                                                                            <?php endif; ?>
                                                                                        </ul>
                                                                                    </div>
                                                                                </div>
                                                                            </td>
                                                                        </tr>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </tbody>
                                                                </table>
                                                            </div><!-- .nk-block -->
<?php /**PATH C:\laragon\www\ConsultorioOdontologico\resources\views/patients/partials/payments.blade.php ENDPATH**/ ?>