<?php $__env->startSection('content'); ?>
                        <!-- start page title -->
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
                                <div class="nk-block-head nk-block-head-sm">
                                    <div class="nk-block-between">
                                        <div class="nk-block-head-content">
                                            <h3 class="nk-block-title page-title">Usuarios</h3>
                                        </div><!-- .nk-block-head-content -->
                                        <div class="nk-block-head-content">
                                            <ul class="nk-block-tools g-3">
                                                <li class="nk-block-tools-opt">
                                                    <a href="<?php echo e(route('user.create')); ?>" class="btn btn-icon btn-primary d-md-none"><em class="icon ni ni-plus"></em></a>
                                                    <a href="<?php echo e(route('user.create')); ?>" class="btn btn-primary d-none d-md-inline-flex"><em class="icon ni ni-plus"></em><span>Agregar Usuario</span></a>
                                                </li>
                                            </ul>
                                        </div><!-- .nk-block-head-content -->
                                    </div><!-- .nk-block-between -->
                                </div><!-- .nk-block-head -->
                                <div class="card card-preview">
                                    <div class="card-inner">
                                        <table class="datatable-init table">
                                            <thead>
                                                <tr>
                                                    <th>Usuario</th>
                                                    <th>Correo</th>
                                                    <th>Rol</th>
                                                    <th>Estatus</th>
                                                    <th class="text-right">Acciones</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($item->name); ?></td>
                                                    <td><?php echo e($item->email); ?></td>
                                                    <td><?php echo e($item->rol->name); ?></td>
                                                    <td>
                                                        <?php if($item->status == 'Activo'): ?>
                                                        <span class="badge badge-primary">Activo</span>
                                                        <?php endif; ?>
                                                        <?php if($item->status == 'Inactivo'): ?>
                                                        <span class="badge badge-danger">Inactivo</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <div class="dropdown float-right pt-0 pb-0">
                                                            <a href="#" class="dropdown-toggle btn btn-icon btn-trigger pt-0 pb-0" data-toggle="dropdown">
                                                                <em class="icon ni ni-more-h"></em>
                                                            </a>
                                                            <div class="dropdown-menu dropdown-menu-right">
                                                                <ul class="link-list-opt no-bdr">
                                                                    <li>
                                                                        <a href="<?php echo e(route('user.show', $item->id)); ?>">
                                                                            <em class="icon ni ni-eye"></em>
                                                                            <span>Ver</span>
                                                                        </a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="<?php echo e(route('user.edit', $item->id)); ?>">
                                                                            <em class="icon ni ni-pen-fill"></em>
                                                                            <span>Editar</span>
                                                                        </a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="#">
                                                                            <em class="icon ni ni-activity-round"></em>
                                                                            <span>Actividades</span>
                                                                        </a>
                                                                    </li>
                                                                    <li>
                                                                        <?php if($item->status == 'Activo'): ?>
                                                                        <a href="#" class="delete-record" data-id="<?php echo e($item->id); ?>">
                                                                            <em class="icon ni ni-power"></em>
                                                                            <span>Desactivar</span>
                                                                        </a>
                                                                        <form id="formDelete-<?php echo e($item->id); ?>" action="<?php echo e(route('user.destroy', ['id' => $item->id])); ?>"method="POST">
                                                                            <?php echo csrf_field(); ?>
                                                                        </form>
                                                                        <?php endif; ?>
                                                                        <?php if($item->status == 'Inactivo'): ?>
                                                                        <a href="#" class="delete-record" data-id="<?php echo e($item->id); ?>">
                                                                            <em class="icon ni ni-power"></em>
                                                                            <span>Activar</span>
                                                                        </a>
                                                                        <form id="formDelete-<?php echo e($item->id); ?>" action="<?php echo e(route('user.destroy', ['id' => $item->id])); ?>"method="POST">
                                                                            <?php echo csrf_field(); ?>
                                                                        </form>
                                                                        <?php endif; ?>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div><!-- .card-preview -->
                            </div>
                        </div>
                        <!-- end page title -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
        <script>
            (function(NioApp, $){
                'use strict';

                $('.datatable-init tbody').on('click', '.delete-record', function(){
                    let dataid = $(this).data('id');
                    let formDelete = $('#formDelete-'+dataid);
                    Swal.fire({
                        title: '¿Está Seguro de Desactivar al Usuario?',
                        text: "Al intentar ingresar al sistema, se le denegará el acceso!",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonText: 'Si, estoy seguro!'
                    }).then((result) => {
                        if (result.value) {
                            $(formDelete).submit();
                        }
                    });
                });

            })(NioApp, jQuery);
        </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ConsultorioOdontologico\resources\views/users/index.blade.php ENDPATH**/ ?>