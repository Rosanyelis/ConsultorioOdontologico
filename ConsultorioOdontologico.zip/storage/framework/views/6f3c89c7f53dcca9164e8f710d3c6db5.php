<?php $__env->startSection('styles'); ?>
        <style>
            #signature-pad {
                border: 2px dotted #CCCCCC;
                border-radius: 5px;
                height: 200px;
            }
        </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
                        <!-- start page title -->
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
                                <div class="nk-block-head nk-block-head-sm">
                                    <div class="nk-block-between">
                                        <div class="nk-block-head-content">
                                            <h3 class="nk-block-title page-title">Pacientes</h3>
                                        </div><!-- .nk-block-head-content -->
                                        <div class="nk-block-head-content">
                                            <ul class="nk-block-tools g-3">
                                                <li class="nk-block-tools-opt">
                                                    <a href="#" class="btn btn-icon btn-info d-md-none">
                                                        <em class="icon ni ni-file-xls"
                                                        data-toggle="modal" data-target="#modalImport"></em></a>
                                                    <a href="#" class="btn btn-info d-none d-md-inline-flex"
                                                        data-toggle="modal" data-target="#modalImport">
                                                        <em class="icon ni ni-file-xls"></em><span>Importar Pacientes</span></a>
                                                    &nbsp;&nbsp;
                                                    <a href="<?php echo e(route('patient.create')); ?>" class="btn btn-icon btn-primary d-md-none"><em class="icon ni ni-plus"></em></a>
                                                    <a href="<?php echo e(route('patient.create')); ?>" class="btn btn-primary d-none d-md-inline-flex"><em class="icon ni ni-plus"></em><span>Agregar Paciente</span></a>

                                                </li>
                                            </ul>
                                        </div><!-- .nk-block-head-content -->
                                    </div><!-- .nk-block-between -->
                                </div><!-- .nk-block-head -->
                                <div class="card card-preview">
                                    <div class="card-inner">
                                        <table class="datatable-init table">
                                            <thead>
                                                <tr>
                                                    <th width="50px">#</th>
                                                    <th>Paciente</th>
                                                    <th>Edad</th>
                                                    <th>Teléfono</th>
                                                    <th>Whatsapp</th>
                                                    <th>Última Visita</th>
                                                    <th class="text-right">Acciones</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td>#<?php echo e($item->id); ?></td>
                                                        <td><?php echo e($item->firstname); ?> <?php echo e($item->lastname); ?></td>
                                                        <td><?php echo e($item->age); ?></td>
                                                        <td><?php echo e($item->phone); ?></td>
                                                        <td><?php echo e($item->whatsapp); ?></td>
                                                        <td><?php echo e($item->last_visit_date); ?></td>
                                                        <td class="text-right">
                                                            <div class="dropdown float-right">
                                                                <a href="#" class="dropdown-toggle btn btn-icon btn-trigger pt-0 pb-0" data-toggle="dropdown">
                                                                    <em class="icon ni ni-more-h"></em>
                                                                </a>
                                                                <div class="dropdown-menu dropdown-menu-right">
                                                                    <ul class="link-list-opt no-bdr">
                                                                        <li>
                                                                            <a href="<?php echo e(route('patient.show', $item->id)); ?>">
                                                                                <em class="icon ni ni-eye"></em>
                                                                                <span>Ver</span>
                                                                            </a>
                                                                        </li>
                                                                        <?php if(!$item->intraoral_exam): ?>
                                                                        <li>
                                                                            <a href="<?php echo e(route('patient.examen-intraoral', $item->id)); ?>">
                                                                                <em class="icon ni ni-note-add"></em>
                                                                                <span>Realizar Examen IntraOral</span>
                                                                            </a>
                                                                        </li>
                                                                        <?php endif; ?>
                                                                        <?php if(!$item->treatment_plan): ?>
                                                                        <li>
                                                                            <a href="<?php echo e(route('patient.treatment-plan', $item->id)); ?>">
                                                                                <em class="icon ni ni-note-add"></em>
                                                                                <span>Realizar Plan de Tratamiento</span>
                                                                            </a>
                                                                        </li>
                                                                        <?php endif; ?>
                                                                        <?php if($item->url_signature == ''): ?>
                                                                        <li>
                                                                            <a href="<?php echo e(route('patient.signature', $item->id)); ?>">
                                                                                <em class="icon ni ni-edit-alt-fill"></em>
                                                                                <span>Agregar Firma</span>
                                                                            </a>
                                                                        </li>
                                                                        <?php endif; ?>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div><!-- .card-preview -->
                            </div>
                        </div>
                        <!-- end page title -->
                        <?php echo $__env->make('patients.partials.modal-import', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ConsultorioOdontologico\resources\views/patients/index.blade.php ENDPATH**/ ?>