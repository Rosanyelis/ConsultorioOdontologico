
            <?php if(session('success')): ?>
            Swal.fire({
                position: 'top-center',
                icon: 'success',
                title: '<?php echo e(session('success')); ?>',
                showConfirmButton: false,
                timer: 2500
            });
            <?php endif; ?>

            <?php if(session('error')): ?>
            Swal.fire({
                position: 'top-center',
                icon: 'error',
                title: '<?php echo e(session('error')); ?>',
                showConfirmButton: false,
                timer: 2500
            });
            <?php endif; ?>

            <?php if(session('warning')): ?>
            Swal.fire({
                position: 'top-center',
                icon: 'warning',
                title: '<?php echo e(session('warning')); ?>',
                showConfirmButton: false,
                timer: 2500
            });
            <?php endif; ?>
<?php /**PATH C:\laragon\www\ConsultorioOdontologico\resources\views/layouts/alerts.blade.php ENDPATH**/ ?>