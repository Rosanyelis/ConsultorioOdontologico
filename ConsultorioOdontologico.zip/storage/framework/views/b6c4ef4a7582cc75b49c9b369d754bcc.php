
<?php $__env->startSection('content'); ?>
                        <!-- start page title -->
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
                                <div class="nk-block-head nk-block-head-sm">
                                    <div class="nk-block-between">
                                        <div class="nk-block-head-content">
                                            <h3 class="nk-block-title page-title">Editar Usuarios</h3>
                                        </div><!-- .nk-block-head-content -->
                                        <div class="nk-block-head-content">
                                            <ul class="nk-block-tools g-3">
                                                <li class="nk-block-tools-opt">
                                                    <a href="<?php echo e(route('user.index')); ?>" class="btn btn-icon btn-secondary d-md-none"><em class="icon ni ni-arrow-left"></em></a>
                                                    <a href="<?php echo e(route('user.index')); ?>" class="btn btn-secondary d-none d-md-inline-flex"><em class="icon ni ni-arrow-left"></em><span>Regresar</span></a>
                                                </li>
                                            </ul>
                                        </div><!-- .nk-block-head-content -->
                                    </div><!-- .nk-block-between -->
                                </div><!-- .nk-block-head -->
                                <div class="card card-preview">
                                    <div class="card-inner">
                                        <form class="row gy-2 form-validate" action="<?php echo e(route('user.update', $data->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <div class="col-4">
                                                <div class="form-group">
                                                    <label class="form-label" for="name">Nombre de Usuario</label>
                                                    <div class="form-control-wrap">
                                                        <input type="text" name="name" class="form-control"
                                                            id="name" placeholder="Ejm: Jane Doe" value="<?php echo e($data->name); ?>">
                                                        <?php if($errors->has('name')): ?>
                                                            <span class="invalid text-danger">
                                                                <?php echo e($errors->first('name')); ?>

                                                            </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-4">
                                                <div class="form-group">
                                                    <label class="form-label" for="name">Rol</label>
                                                    <div class="form-control-wrap">
                                                        <select class="form-select" name="rol_id" data-placeholder="Seleccione un rol">
                                                            <option value="">Seleccione un rol</option>
                                                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($item->id); ?>" <?php if($data->rol_id == $item->id): ?>  selected <?php endif; ?>><?php echo e($item->name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                        <?php if($errors->has('rol_id')): ?>
                                                            <span class="invalid text-danger">
                                                                <?php echo e($errors->first('rol_id')); ?>

                                                            </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-4">
                                                <div class="form-group">
                                                    <label class="form-label" for="correo">Correo</label>
                                                    <div class="form-control-wrap">
                                                        <input type="email" name="email" class="form-control"
                                                            id="correo" placeholder="Ejm: janedoe@example.com"
                                                            value="<?php echo e($data->email); ?>">

                                                        <?php if($errors->has('email')): ?>
                                                            <span class="invalid text-danger">
                                                                <?php echo e($errors->first('email')); ?>

                                                            </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-4">
                                                <div class="form-group">
                                                    <label class="form-label" for="password">Contraseña</label>
                                                    <div class="form-control-wrap">
                                                        <input type="password" name="password" class="form-control"
                                                            id="password" placeholder="*********" >
                                                        <?php if($errors->has('password')): ?>
                                                            <span class="invalid text-danger">
                                                                <?php echo e($errors->first('password')); ?>

                                                            </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-12">
                                                <div class="form-group float-right">
                                                    <button type="submit" class="btn btn-primary">Guardar Usuario</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div><!-- .card-preview -->
                            </div>
                        </div>
                        <!-- end page title -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ConsultorioOdontologico\resources\views/users/edit.blade.php ENDPATH**/ ?>