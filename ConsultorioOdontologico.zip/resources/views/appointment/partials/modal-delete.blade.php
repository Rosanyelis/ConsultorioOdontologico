    <div class="modal fade" id="deleteEventPopup">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body modal-body-lg text-center">
                    <div class="nk-modal py-4">
                        <em class="nk-modal-icon icon icon-circle icon-circle-xxl ni ni-cross bg-danger"></em>
                        <h4 class="nk-modal-title">¿ Está seguro de eliminar la cita ?</h4>

                        <ul class="d-flex justify-content-center gx-4 mt-4">
                            <li>
                                <button type="button" id="deleteEvent" class="btn btn-success"
                                >Si, borrar cita</button>
                            </li>
                            <li>
                                <button data-dismiss="modal" data-toggle="modal" class="btn btn-danger btn-dim">Cancelar</button>
                            </li>
                        </ul>
                    </div>
                </div><!-- .modal-body -->
            </div>
        </div>
    </div>
